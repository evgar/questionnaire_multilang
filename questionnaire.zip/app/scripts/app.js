import svg4everybody from 'svg4everybody';
import $ from 'jquery';
import '../blocks/js-level/js-level.js';
import '../blocks/textfield/subject-info.js';

$(() => {
	svg4everybody();
});
